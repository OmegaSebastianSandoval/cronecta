# Bootstrap Color Picker Sliders [![Build Status](https://secure.travis-ci.org/istvan-ujjmeszaros/bootstrap-colorpickersliders.png?branch=master)](https://travis-ci.org/istvan-ujjmeszaros/bootstrap-colorpickersliders)

Bootstrap 3 optimized responsive color selector with HSV, HSL, RGB and CIE-Lch (which supports human perceived lightness) selectors and color swatches.

- [Website](http://www.virtuosoft.eu/code/bootstrap-colorpickersliders/)

Please report issues and feel free to make feature suggestions as well.

## License

Apache License, Version 2.0
